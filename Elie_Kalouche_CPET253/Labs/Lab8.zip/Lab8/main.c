#include "msp.h"
#include <msp432.h>
#include <stdint.h>
#include <stdbool.h>
#include "../inc/Clock.h"
#include "../inc/CortexM.h"
#include "../inc/motor.h"
#include "../inc/Init_Ports.h"
#include "../inc/Init_Timers.h"
#include "../inc/Reflectance.h"

void main(void)
{
    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;     // stop watchdog timer
    Clock_Init48MHz();  // makes bus clock 48 MHz

    // call all the port initialization functions
    Port2_Init();
    Port3_Init();
    Port5_Init();
    Port7_Init();
    Port9_Init();

    // call all the timer initialization functions
    TimerA0_Init();

    // These are the states of the state machine
    enum motor_states {M_Forward, M_Left, M_Right} state, prevState;

    state     = M_Forward;  // start in FORWARD state
    prevState = -1;         // FIX: use -1 sentinel so isNewState is true on first loop

    uint16_t stateTimer = 0;  // used to stay in a state
    bool isNewState;          // true when the state has switched

    P2OUT = 0x00;

    while(1)
    {
        isNewState = (state != prevState);
        prevState  = state;  // save state for next iteration

        // FIX: use correct type uint8_t to match Reflectance_Read return type
        uint8_t  temp       = Reflectance_Read(1000);
        int32_t  ReflectVal = Reflectance_Position(temp);

        switch(state)
        {
            case M_Forward:
                if(isNewState)
                {
                    Motor_Forward(6000, 5800);
                }
                if(ReflectVal < -95)
                {
                    state = M_Right;
                }
                else if(ReflectVal > 95)
                {
                    state = M_Left;
                }
                break;

            case M_Right:
                if(isNewState)
                {
                    Motor_Right(0, 6500);
                }
                // FIX: return to forward when value is back near center (>= -95, not >= 95)
                if(ReflectVal >= -95)
                {
                    state = M_Forward;
                }
                break;

            case M_Left:
                if(isNewState)
                {
                    Motor_Left(6500, 0);
                }
                // FIX: return to forward when value is back near center (<= 95, not <= -95)
                if(ReflectVal <= 95)
                {
                    state = M_Forward;
                }
                break;

            default:
                state = M_Forward;  // FIX: was a no-op expression, now actually resets state
                break;

        } // switch

        Clock_Delay1ms(10);

    } // while
}
